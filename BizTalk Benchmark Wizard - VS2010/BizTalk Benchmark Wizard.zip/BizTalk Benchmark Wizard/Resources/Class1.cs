﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BizTalk_Benchmark_Wizard.Resources
{
    // This is just a dummy class to avoid getting stupid compile issues...
    class Class1
    {
    }
}
